/* $Id: ntp.h,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $ */
extern void ntp_input(struct Packet *packet);
extern void ntp_clockup();
