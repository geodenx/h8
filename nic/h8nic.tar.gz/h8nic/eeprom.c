/*****************************************************************
 * $Id: eeprom.c,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $
 *
 * 24LC64 === H8LAN
 *    SCL --- P6-1
 *    SDA --- P6-0
 *    A0  --- GND
 *    A1  --- GND
 *    A2  --- GND
 *    WP  --- GND
 * 
 * Reference:
 *  [1] Tr�� 2002 1 Pp.193-198 
 *          Chapter 3. Appendix "Serial EEPROM�μ����μ�"
 *  [2] eeprom.c
 *          24LC64 Serial EEPROM Driver 
 *          Copyright (C) 1998 Koji Suzuki
 *          
 *          eeprom_read(offset, address, bytes)
 *          EEPROM ��� offset ������ΰ�� address ����Ϥޤ�
 *          �����ž�������ｪλ���� 0 ���֤���
 *          
 *          eeprom_write(offset, address, bytes)
 *          EEPROM ��� offset ������ΰ�� address ����Ϥޤ�
 *          ��������Ƥ�ž�������ｪλ���� 0 ���֤���
 *
 *  [3] Microchip Technology Inc., 24AA64/24LC64 Data Sheet
 *  [4] Phipips Semiconductors, The I2C-bus and how to use it (include specifications)
 *  [5] i2c.c Generic i2c interface for Linux
 *
 ****************************************************************/

#ifdef AKI
#include <3067f.h>
#define EEPROM_DDR	P6DDR
#define EEPROM_DR	P6DR.BYTE

#elif H8NIC
#include <3048f.h>
#define EEPROM_DDR	P6.DDR
#define EEPROM_DR	P6.DR.BYTE
#endif /*  */

#define SCL		(0x02)
#define SDA		(0x01)

#define outb(x, y)      {(x) = (y);asm("nop");}

/****************************************************************
* Private Routine
*****************************************************************/
unsigned char eeprom_ddr;

static void write_bit(char data) {
    eeprom_ddr |= SCL;		/* SCL -> Out (L) */
    outb(EEPROM_DDR, eeprom_ddr);
    if (data) {
	eeprom_ddr &= ~SDA;	/* SDA -> In (H) */
    } else {
	eeprom_ddr |= SDA;	/* SDA -> Out (L) */
    }
    outb(EEPROM_DDR, eeprom_ddr);
    eeprom_ddr &= ~SCL;		/* SCL -> In (H) */
    outb(EEPROM_DDR, eeprom_ddr);
}

static char read_bit() {
    eeprom_ddr &= ~SDA;		/* SDA -> In (H) */
    eeprom_ddr |= SCL;		/* SCL -> Out (L) */
    outb(EEPROM_DDR,eeprom_ddr);
    eeprom_ddr &= ~SCL;		/* SCL -> In (H) */
    outb(EEPROM_DDR,eeprom_ddr);
    
    return (EEPROM_DR & SDA);
}

static void start_condition() {
    eeprom_ddr &= ~SCL;		/* SCL -> In (H) */
    outb(EEPROM_DDR, eeprom_ddr);
    eeprom_ddr |= SDA;		/* SDA -> Out (L <-default) */
    outb(EEPROM_DDR, eeprom_ddr);
}

static void stop_condition() {
    write_bit(0);		/* SCL -> L, SDA -> L, SCL -> H */
    eeprom_ddr &= ~SDA;		/* SDA -> H */
    outb(EEPROM_DDR,eeprom_ddr);
}

static void write_byte(char data)
{
    char i, x = 0x80;

    for (i = 0; i < 8; i++) {
	write_bit(data & x);
	x >>= 1;
    }
}

static char read_byte() {
    char i, ret = 0;
    
    for (i = 0; i < 8; i++) { 
	ret <<= 1;
	ret |= read_bit() ? 1 : 0;
    }
    return ret;
}

/****************************************************************
* Public Routine
****************************************************************/
/* Page Write */
char eeprom_write(int offset, char *buf, int bytes)
{
    char i, flag = 1;
    
    while (bytes > 0) {
	start_condition();
	write_byte(0xa0);	/* Control Byte (A0,1,2 == L) */
	if (read_bit()) {	/* NACK */
	    if(!flag)		/* �����������Ƥʤ��ä��� */
		continue;	
	    stop_condition();
	    return 1;		/* �����������Ȥ����ä�NACK���ä��� */
	}
	write_byte(offset >> 8); /* Address High Byte */
	if (read_bit()) { stop_condition(); return 2; } /* NACK */
	write_byte(offset);	/* Address Low Byte */
	if (read_bit()) { stop_condition(); return 3; }	/* NACK */
	//for (i = 0; (i < 32) && (bytes > 0); i++) { /* Page Write (till 32byte)*/
	for (i = 0; (i < 16) && (bytes > 0); i++) { /* Page Write (till 32byte)*/
	    write_byte(*buf);	/* Data Byte */
	    //sci_puts(hex2str(*buf)); /* debug */
	    if (read_bit()) { stop_condition(); return 4; } /* NACK */
	    offset++;
	    buf++;
	    bytes--;
	}
	stop_condition();
	flag = 0;		/* �������������� */
    }

    return 0;
}

/* Sequential Read */
char eeprom_read(int offset, char *buf, int bytes)
{
    start_condition();
    write_byte(0xa0);		/* Control Byte (A0,1,2 == L) (Write) */
    if (read_bit()) { stop_condition(); return 1; } /* NACK */
    write_byte(offset >> 8);	/* Address High Byte */
    if (read_bit()) { stop_condition(); return 2; } /* NACK */
    write_byte(offset);		/* Address Low Byte */
    if (read_bit()) { stop_condition(); return 3; } /* NACK */
    stop_condition();

    start_condition();
    write_byte(0xa1);		/* Control Byte (A0,1,2 == L) (Read) */
    if (read_bit()) { stop_condition(); return 4; } /* NACK */

    while (bytes > 0) {
	*buf = read_byte();
	//sci_puts(hex2str(*buf)); /* debug */
	if (bytes > 1)		/* ³���ƥǡ������ߤ����Ȥ�ACK */
	    write_bit(0); /* ACK */
	else
	    write_bit(1); /* NO ACK (NACK)*/
	offset++;
	buf++;
	bytes--;
    }

    return 0;
}
