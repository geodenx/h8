/****************************************************************
 * H8NIC Project
 * LCD driver
 *
 *	PB  - LCD (data bus: 4 bit)
 *
 *	PB0 - D4
 *	PB1 - D5
 *	PB2 - D6
 *	PB3 - D7
 *	PB4 - E
 *	PB5 -
 *	PB6 - Rs
 *	PB7 - R/~W
 *
 * Reference:
 *    http://member.nifty.ne.jp/softbone/OneBoard/H8Template/
 *    http://www.kajitani.mce.uec.ac.jp/user/kazu/tech/gcc/
 *
 * $Id: lcd.c,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $
 *
 *****************************************************************/
#ifdef H8NIC
#include <3048f.h>
#elif AKI
#include <3067f.h>
#endif /* H8NIC|AKI */

static void LcdWriteIR(unsigned char data);
static unsigned char LcdReadIR(void);
static void LcdWriteDR(unsigned char data);
static unsigned char LcdReadDR(void);
static void LcdWrite(unsigned char data);
static unsigned char LcdRead(void);
static void LcdWriteIR4(unsigned char data);
static short LcdBusy(void);
static void Delay(unsigned long msec);

static short lcdx, lcdy;

/*  Public routine: Initialize LCD */
void LcdInit(void)
{
    // Reset LCD 
#ifdef H8NIC
    PB.DDR = 0xff;		/* LCD����饤�� */
    PB.DR.BYTE = 0;
#elif AKI
    PBDDR = 0xff;		/* LCD����饤�� */
    PBDR.BYTE = 0;
    P4DR.BIT.B7 = 0;
#endif /* H8NIC|AKI */
    // ������������� 
    Delay(20);			// Wait 20 ms 
    LcdWriteIR4(0x03);
    Delay(5);
    LcdWriteIR4(0x03);
    Delay(1);
    LcdWriteIR4(0x03);
    Delay(1);
    LcdWriteIR4(0x02);		// Data length 4bits 
    Delay(1);

    while (LcdBusy());
    LcdWriteIR(0x28);		// Set function 

    while (LcdBusy());
    LcdWriteIR(0x08);		// Display off, cursor off, blink off 

    while (LcdBusy());
    LcdWriteIR(0x01);		// Clear display 

    while (LcdBusy());
    LcdWriteIR(0x06);		// Entry mode : cursor increment 

    while (LcdBusy());
    LcdWriteIR(0x0C);		// Display on, cursor off, blink off 

    lcdx = lcdy = 0;
}

/*  Public routine: ɽ��������� */
void LcdLocate(unsigned char x, unsigned char y)
{
    unsigned char addr;

    switch (y)
	{
	case 0:
	    addr = 0x00 + x;
	    break;
	case 1:
	    addr = 0x40 + x;
	    break;
	case 2:
	    addr = 0x14 + x;
	    break;
	case 3:
	    addr = 0x54 + x;
	    break;
	default:
	    return;
	}

    lcdx = x;
    lcdy = y;
    while (LcdBusy());
    LcdWriteIR(0x80 | addr);		// Set DD RAM address
}

/*  Public routine: Clear LCD, go to home */
void LcdCls(void)
{
    while (LcdBusy());
    LcdWriteIR(0x01);
    lcdx = lcdy = 0;
}

/*  Public routine: Display cursor */
void LcdDispCursor(unsigned char on)
{
    while (LcdBusy());
    LcdWriteIR(0x0C | (on ? 0x02 : 0));
}

/*  Public routine: Back Space */
void LcdBS(void)
{
    if (!lcdx)
	return;
    lcdx--;
    LcdLocate(lcdx, lcdy);
}

/*  Public routine: Put char */
void LcdPutCh(unsigned char c)
{
    if (c == '\b') {
	LcdBS();
	return;
    }
    while (LcdBusy())
	;
    LcdWriteDR(c);
    lcdx++;
}

/*  Public routine: Put strings */
void LcdPutStr(unsigned char *str)
{
    while (*str)
	LcdPutCh(*(str++));
}


/*****************************************************************
 *  Private routine
 *****************************************************************/
static void nop(void)
{
#ifdef AKI
    asm("nop");
#endif /* AKI */
}

//	LCD Drive primitive
//	Data length = 4bits

#ifdef H8NIC
#define ASSERT_RS()	{ PB.DR.BIT.B6 = 1; }
#define ASSERT_E()	{ PB.DR.BIT.B4 = 1; }
#define ASSERT_RW()	{ PB.DR.BIT.B7 = 1; }

#define NEGATE_RS()	{ PB.DR.BIT.B6 = 0; }
#define NEGATE_E()	{ PB.DR.BIT.B4 = 0; }
#define NEGATE_RW()	{ PB.DR.BIT.B7 = 0; }

#define WRITE_MODE()	{ PB.DDR = 0xff; }
#define WRITE_DATA(x)	{ PB.DR.BYTE = (PB.DR.BYTE & 0xf0) | ((x) & 0x0f); }

#define READ_MODE()	{ PB.DDR = 0xf0; }
#define READ_DATA()	(PB.DR.BYTE)
#elif AKI
#define ASSERT_RS()	{ PBDR.BIT.B6 = 1; }
#define ASSERT_E()	{ P4DR.BIT.B7 = 1; }
#define ASSERT_RW()	{ PBDR.BIT.B7 = 1; }

#define NEGATE_RS()	{ PBDR.BIT.B6 = 0; }
#define NEGATE_E()	{ P4DR.BIT.B7 = 0; }
#define NEGATE_RW()	{ PBDR.BIT.B7 = 0; }

#define WRITE_MODE()	{ PBDDR = 0xff; }
#define WRITE_DATA(x)	{ PBDR.BYTE = (PBDR.BYTE & 0xf0) | ((x) & 0x0f); }

#define READ_MODE()	{ PBDDR = 0xf0; }
#define READ_DATA()	(PBDR.BYTE)
#endif /* H8NIC|AKI */

static void LcdWriteIR(unsigned char data)
{
    NEGATE_RS();
    LcdWrite(data);
}


static unsigned char LcdReadIR(void)
{
    NEGATE_RS();
    return LcdRead();
}


static void LcdWriteDR(unsigned char data)
{
    ASSERT_RS();
    LcdWrite(data);
}


static unsigned char LcdReadDR(void)
{
    ASSERT_RS();
    return LcdRead();
}


static void LcdWrite(unsigned char data)
{
    WRITE_MODE();

    NEGATE_RW();
    nop();

    ASSERT_E();
    WRITE_DATA(data >> 4);
    nop();
    NEGATE_E();

    nop();
	
    ASSERT_E();
    WRITE_DATA(data);
    nop();
    NEGATE_E();
}


static unsigned char LcdRead(void)
{
    unsigned char data;

    READ_MODE();

    ASSERT_RW();
    nop();

    ASSERT_E();
    nop();
    data = READ_DATA() << 4;
    NEGATE_E();
	
    nop();

    ASSERT_E();
    nop();
    data |= READ_DATA() & 0x0f;
    NEGATE_E();

    return data;
}


static void LcdWriteIR4(unsigned char data)
{
    WRITE_MODE();

    NEGATE_RS();
    NEGATE_RW();
    nop();

    ASSERT_E();
    WRITE_DATA(data);
    nop();
    NEGATE_E();
}

static short LcdBusy(void)
{
    return LcdReadIR() & 0x80;
}

static void Delay(unsigned long msec)
{
    unsigned long t;
    unsigned short i;
    for(t = 0; t < msec; t++) {
#ifdef H8NIC
	for(i = 0; i < 100; i++); // ms 
#elif AKI
	for(i = 0; i < 180; i++); // ms 
#endif /* H8NIC|AKI */
    }
}
