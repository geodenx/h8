/*****************************************************************
 * H8NIC Prokect
 * utility program: timer, converter (hex2str)
 *
 * $Id: util.h,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $
 *
 ****************************************************************/

extern void waitms(int i);
extern unsigned char *hex2str(unsigned char c);
extern unsigned char *hex22str(unsigned char s);
