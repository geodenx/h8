/*****************************************************************
 * H8NIC Prokect
 * utility program: timer, converter
 *
 * $Id: util.c,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $
 *
 ****************************************************************/

#ifdef H8NIC
#include <3048f.h>
#elif AKI
#include <3067f.h>
#endif

static void waittimer(void);
void waitms(int i);
unsigned char *hex2str(unsigned char c);

/*  Private routine: call from waitms */
static void waittimer(void)
{
#ifdef H8NIC
    while ((ITU0.TSR.BYTE& 1) == 0);
    ITU0.TSR.BYTE = 0xfe;
#elif AKI
    while ((ITU.TISRA.BYTE& 1) == 0);
    ITU.TISRA.BYTE &= 0xfe;
#endif
}

/*  Public rutine: Wait milli seconds */
void waitms(int i)
{
    for (; i ; i--)
	waittimer();
}


/* Public routine: conver hex (1 byte) to 2 strings */
static unsigned char hex2str_s[3];	/* global variable for hex2str */
unsigned char *hex2str(unsigned char c)
{
    static char hex[17] = "0123456789ABCDEF";

    hex2str_s[0] = hex[ c >> 4 ];
    hex2str_s[1] = hex[ c & 0x0f ];
    hex2str_s[2] = '\0';
    
    return hex2str_s;
}

/* Public routine: conver hex (2 byte) to 2 strings */
static unsigned char hex22str_s[5];	/* global variable for hex22str */
unsigned char *hex22str(unsigned short s)
{
    hex22str_s[0] = *hex2str((unsigned char)(s >> 8));
    hex22str_s[1] = *(hex2str((unsigned char)(s >> 8))+1);
    hex22str_s[2] = *hex2str((unsigned char)(s & 0xff));
    hex22str_s[3] = *(hex2str((unsigned char)(s & 0xff))+1);
    hex22str_s[4] = '\0';

    return hex22str_s;
}
