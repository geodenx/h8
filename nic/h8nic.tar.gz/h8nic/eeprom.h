/* $Id: eeprom.h,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $ */
#ifndef _EEPROM_H_
#define _EEPROM_H_

extern char eeprom_write(int offset, char *buf, int bytes);
extern char eeprom_read(int offset, char *buf, int bytes);

#endif /* _EEPROM_H_ */
