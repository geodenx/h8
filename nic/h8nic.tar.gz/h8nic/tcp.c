/*
 * "CUST-A-NETS" (CUSTodian Annexed NETwork Support)
 *                     LAN adaptor ITRON & TCP/IP routines
 *
 * Copyright (C) 1999,2000,2001 by Oh!Ishi/Biwajima,N
 *                                          Nibbles lab., JAPAN
 * Copyright (C) 2001 by MURANAKA Masaki (TOPPERS/JSP porting)
 *
 * Copyright (C) 2002 by OKAZAKI Atsuya (H8 porting)
 *
 * �嵭����Ԥϡ��ʲ��ξ������������˸¤ꡤ�ܥ��եȥ��������ܥ�
 * �եȥ���������Ѥ�����Τ�ޤࡥ�ʲ�Ʊ���ˤ���ѡ�ʣ�������ѡ�����
 * �ۡʰʲ������ѤȸƤ֡ˤ��뤳�Ȥ�̵���ǵ������롥
 * (1) �ܥ��եȥ������򥽡��������ɤη������Ѥ�����ˤϡ��嵭������
 *     ��ɽ�����������Ѿ�浪��Ӳ�����̵�ݾڵ��꤬�����Τޤޤη��ǥ���
 *     ����������˴ޤޤ�Ƥ��뤳�ȡ�
 * (2) �ܥ��եȥ�������Х��ʥꥳ���ɤη��ޤ��ϵ�����Ȥ߹����������
 *     �Ѥ�����ˤϡ����Τ����줫�ξ������������ȡ�
 *   (a) ���Ѥ�ȼ���ɥ�����ȡ����Ѽԥޥ˥奢��ʤɡˤˡ��嵭������
 *       ��ɽ�����������Ѿ�浪��Ӳ�����̵�ݾڵ����Ǻܤ��뤳�ȡ�
 *   (b) ���Ѥη��֤��̤�������ˡ�ˤ�äơ��嵭����Ԥ���𤹤�
 *       ���ȡ�
 * (3) �ܥ��եȥ����������Ѥˤ��ľ��Ū�ޤ��ϴ���Ū�������뤤���ʤ�»
 *     ������⡤�嵭����Ԥ����դ��뤳�ȡ�
 *
 * �ܥ��եȥ������ϡ�̵�ݾڤ��󶡤���Ƥ����ΤǤ��롥�嵭����Ԥϡ�
 * �ܥ��եȥ������˴ؤ��ơ�����Ŭ�Ѳ�ǽ����ޤ�ơ������ʤ��ݾڤ�Ԥ�
 * �ʤ����ޤ����ܥ��եȥ����������Ѥˤ��ľ��Ū�ޤ��ϴ���Ū����������
 * ���ʤ�»���˴ؤ��Ƥ⡤������Ǥ�����ʤ���
 *
 * $Id: tcp.c,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $
 *
 */

#include <itron.h>
#include "tcpip.h"
#include "tcp.h"
#include "ether.h"
#include "ip.h"
#include "lan-util.h"
#include <sci.h>
#include <util.h>
#include <string.h>

char rcpt[100] = "RCPT TO: okazaki@tl.cc.uec.ac.jp\r\n";

//int ne_bcompare( unsigned char *, unsigned char *, unsigned int );

char tcp_got_syn_packet(struct Packet *packet, T_TSOCK *sock);
void http_output(struct Packet *packet);
char smtp_output(struct Packet *packet, char cmd);
void send_tcp(T_TSOCK *sock, char flags, struct Packet *packet, char *data, unsigned int size);
    
/* TCP, HTTP layer */

char tcp_got_syn_packet(struct Packet *packet, T_TSOCK *sock)
{
    char recepted = FALSE;
    unsigned char *tcp_hdr;

    tcp_hdr = packet->ptr + SIZEOF_IPHDR;

#ifdef HTTP /* passive open (HTTP server) */
    if (sock->status != LISTEN) {
	sci_puts("tcp_got_syn_packet: status != LISTEN\n");
    } else {
	sock->status = SYN_RCVD;
	sci_puts("tcp_got_syn_packet: SYN_RCVD\n");
	recepted = TRUE;
	sock->ack = packet_get_nl(tcp_hdr, tcphdr_seq) + 1;
	send_tcp(sock, TCP_FLAG_SYN | TCP_FLAG_ACK, packet, NULL, 0);
    }
#endif /* HTTP */
#ifdef SMTP /* active open (SMTP client) ARP request��? */
    //    if (sock->status == SYN_SENT) {
    sock->status = ESTABLISHED;
    sci_puts("tcp_got_syn_packet: ESTABLISHED\n");
    sock->ack = packet_get_nl(tcp_hdr, tcphdr_seq) + 1;
    send_tcp(sock, TCP_FLAG_ACK, packet, NULL, 0);
	//    }
#endif /* SMTP */
    return recepted;
}

void tcp_got_ack_packet(struct Packet *packet, T_TSOCK *sock)
{
#ifdef HTTP /* passive open, active close (HTTP server) */
    if (sock->status == SYN_RCVD) {
	sock->status = ESTABLISHED;
	sci_puts("tcp_got_ack_packet: ESTABLISHED\n");
    } else if (sock->status == ESTABLISHED) {
	sock->status = FIN_WAIT_1;
	sci_puts("tcp_got_ack_packet: FIN_WAIT_1\n");
	send_tcp(sock, TCP_FLAG_FIN | TCP_FLAG_ACK, packet, NULL, 0);
    } else if (sock->status == FIN_WAIT_1) {
	sock->status = FIN_WAIT_2;
	sci_puts("tcp_got_ack_packet: FIN_WAIT_2 (!)\n");
    }
#endif /* HTTP */
#ifdef SMTP /* active open, passive close (SMTP client) */
    if (sock->status == ESTABLISHED) {
	sci_puts("tcp_got_ack_packet: ESTABLISHED (still)\n");
	send_tcp(sock, TCP_FLAG_ACK, packet, NULL, 0);
    } else if (sock->status == LAST_ACK) {
	sock->status = CLOSED;
	sci_puts("tcp_got_ack_packet: CLOSED\n");
    }
#endif /* SMTP */
}

char tcp_got_fin_packet(struct Packet *packet, T_TSOCK *sock)
{
    char consumed = FALSE;
    unsigned char *tcp_hdr;

    tcp_hdr = packet->ptr + SIZEOF_IPHDR;

#ifdef HTTP /* active close (HTTP server) */
    if (sock->status == ESTABLISHED) {
	sock->status = CLOSE_WAIT;
	sci_puts("tcp_got_fin_packet: LESTEN\n");
	consumed = TRUE;
    } else if (sock->status == FIN_WAIT_2) {
	sock->status = LISTEN;
	sci_puts("tcp_got_fin_packet: LESTEN (TIME_WAIT)\n");
	consumed = TRUE;
    } else {
	sock->status = LISTEN;	/* debug */
	sci_puts("tcp_got_fin_packet: LESTEN (debug!)\n");
    }

    if (consumed == TRUE) {
	sock->ack = packet_get_nl(tcp_hdr, tcphdr_seq) + 1;
	send_tcp(sock, TCP_FLAG_ACK, packet, NULL, 0);
    }
#endif /* HTTP */
#ifdef SMTP /* passive close (SMTP client) */
    if (sock->status == ESTABLISHED) {
	sock->ack = packet_get_nl(tcp_hdr, tcphdr_seq) + 1;
	send_tcp(sock, TCP_FLAG_ACK, packet, NULL, 0);
	/* sock->status = CLOSE_WAIT; */
	send_tcp(sock, (TCP_FLAG_FIN | TCP_FLAG_ACK), packet, NULL, 0);
	sock->status = LAST_ACK;
	sci_puts("tcp_got_fin_packet: LAST_ACK\n");
    } else {
	sock->ack = packet_get_nl(tcp_hdr, tcphdr_seq) + 1;
	send_tcp(sock, TCP_FLAG_ACK, packet, NULL, 0);
	send_tcp(sock, (TCP_FLAG_FIN | TCP_FLAG_ACK), packet, NULL, 0);
	sock->status = CLOSED;
    }
#endif /* SMTP */
    
    return consumed;
}


char tcp_got_normal_packet(struct Packet *packet, T_TSOCK *sock)
{
    int consumed = FALSE;
    int payload_len;

    unsigned char *tcp_hdr;
    unsigned char *tcp_body;
    int ip_hdr_len;
    int tcp_hdr_len;

    sci_puts("tcp_got_normal_packet:\n");
    
    ip_hdr_len = (packet->ptr[iphdr_version] & 0xf) * 4;
    tcp_hdr = packet->ptr + ip_hdr_len;
    tcp_hdr_len = (tcp_hdr[tcphdr_len] >> 4) * 4;
    tcp_body = tcp_hdr + tcp_hdr_len;

    payload_len = packet_get_n(packet->ptr /* ip_hdr */, iphdr_len) - (ip_hdr_len + tcp_hdr_len);

    if (payload_len == 0) {
	return FALSE;
    }

    if (sock->status == ESTABLISHED) {
	consumed = TRUE;
    } else if (sock->status == SYN_RCVD) { /* for MacOS! */
	sock->status = ESTABLISHED;
	consumed = TRUE;
    }

    if (consumed == TRUE) {
	sock->ack = packet_get_nl(tcp_hdr, tcphdr_seq) + payload_len;
	send_tcp(sock, TCP_FLAG_ACK, packet, NULL, 0);
    }

    return consumed;
}

#if 0
void tcp_output(struct Packet *packet)
{
    static int i;

    int size;
    size = winfo->len;
    if (cb->cep->cepinib->sbufsz - cb->cep->sbuflen < size) {
	size = cb->cep->cepinib->sbufsz - cb->cep->sbuflen;
    }
    packet_memcpy(cb->cep->cepinib->sbuf + cb->cep->sbuflen, winfo->data, size);
    cb->cep->sbuflen += size;
    
    if (cb->cep->sbuflen > 0) {
	{
	    char *sbuf;
	    int sbuflen;

	    sbuf = cb->cep->cepinib->sbuf;
	    sbuflen = cb->cep->sbuflen;

	    size = 1024;
	    if (sbuflen < size) {
		size = sbuflen;
	    }
	    syscall(get_mpf(MPF_PACKET, (VP*)&packet));
	    send_tcp(cb->cep, TCP_FLAG_PSH, packet, sbuf, size);
	    cb->cep->seq_count += size;
	    cb->cep->sbuflen -= size;
	    packet_memcpy(sbuf, sbuf + size, cb->cep->sbuflen);
	}
    } else {
	extern TCP_CLSCB tcp_clscb_table[];
	static TCP_CLSCB *clscb;

	char send_fin = FALSE;
	clscb = &tcp_clscb_table[i];

	if (clscb->cep->status != TCP_CEP_STATUS_LAST_ACK &&
	    queue_empty(&(clscb->wait_queue)) == FALSE) {
	    send_fin = TRUE;
	    clscb->cep->status = TCP_CEP_STATUS_LAST_ACK;
	}

	if (send_fin) {
	    struct Packet *packet;
	    syslog(LOG_NOTICE, "send_fin");
	    syscall(get_mpf(MPF_PACKET, (VP*)&packet));
	    send_tcp(clscb->cep, TCP_FLAG_FIN | TCP_FLAG_ACK, packet, NULL, 0);
	}
    }
}
#endif /* 0 */

#ifdef HTTP
void http_output(struct Packet *packet)
{
    unsigned int size;
    unsigned char html[] = "HTTP/1.0 200 OK\r\nContent-type: text/html\r\n\r\n<HTML><HEAD><TITLE>H8NIC</TITLE></HEAD><BODY>H8NIC test page</BODY></HTML>\r\n";

    sci_puts("http_output:\n");
    
    size = 118;
    send_tcp(&dest, (TCP_FLAG_ACK | TCP_FLAG_PSH), packet, html, size);
}
#endif /* HTTP */


#ifdef SMTP
static char smtp_status;
char smtp_output(struct Packet *packet, char cmd)
{
    
    if (cmd == 0) {
	smtp_status = CLOSED;	/* ��󤢤뤤��RST�����ä��Ȥ� */
/* 	dest.status = CLOSED; */
/* 	if (dest.myport < 2048) */
	dest.myport = 4015;
/*  	++dest.myport; */
    }

#ifdef __SCI_DEBUG__
    sci_puts("  smtp_output: smtp_status: ");
    sci_puts(hex2str(smtp_status));
    sci_putc('\n');
#endif /* __SCI_DEBUG__ */

    switch (smtp_status) {
    case 0:
	sci_puts("smtp_output: SYN_SENT\n");
	dest.ip = smtp_server;
	//dest.ip = 0xD3848062; /* bc.wakwak.com (211.132.128.98) */
	dest.youport = 25;
	dest.status = SYN_SENT;
	send_tcp(&dest, TCP_FLAG_SYN, packet, NULL, 0);
	break;
    case 1:			/* HELO */
	sci_puts("smtp_output: HELO\n");
	send_tcp(&dest, (TCP_FLAG_ACK | TCP_FLAG_PSH), packet,
		 "HELO localhost\r\n", 16); /* "HELO localhost\r\n" */
	break;
    case 2:			/* MAIL */
	sci_puts("smtp_output: MAIL\n");
	send_tcp(&dest, (TCP_FLAG_ACK | TCP_FLAG_PSH), packet,
		 "MAIL FROM: okazaki@tl.cc.uec.ac.jp\r\n", 36);
	break;
    case 3:			/* RCPT */
	sci_puts("smtp_output: RCPT\n");
	send_tcp(&dest, (TCP_FLAG_ACK | TCP_FLAG_PSH), packet,
	         rcpt, strlen(rcpt));
	break;
    case 4:			/* DATA */
	sci_puts("smtp_output: DATA\n");
	send_tcp(&dest, (TCP_FLAG_ACK | TCP_FLAG_PSH), packet,
		 "DATA\r\n", 6);
	break;
    case 5:			/* mail body */
	sci_puts("smtp_output: --- data ---\n");
	send_tcp(&dest, (TCP_FLAG_ACK | TCP_FLAG_PSH), packet,
		 "This is the test mail from H8NIC.\r\n", 35);
	break;
    case 6:			/* . */
	sci_puts("smtp_output: .\n");
	send_tcp(&dest, (TCP_FLAG_ACK | TCP_FLAG_PSH), packet,
		 ".\r\n", 3);
	break;
    case 7:			/* QUIT */
	sci_puts("smtp_output: QUIT\n");
	send_tcp(&dest, (TCP_FLAG_ACK | TCP_FLAG_PSH), packet,
		 "QUIT\r\n", 6);
	break;
    default:			/* Error */
	sci_puts("smtp_output: (clear smtp_status)\n");
	smtp_status = -1;
	break;
    }
    ++smtp_status;

    return smtp_status;
}
#endif /* SMTP */

/* TCP uplink to application */
T_TSOCK dest = { LISTEN, NULL, NULL, NULL, 1, NULL };

void tcp_input(struct Packet *packet)
{ 
    char recepted = FALSE;

    unsigned char flag;
    unsigned char *ip_hdr;
    unsigned char *tcp_hdr;
    static T_TSOCK rec;

    //sci_puts("tcp_input:\n");

#ifdef HTTP	/* port (protocol) */
    dest.myport = 80;		/* HTTP */
    ip_hdr = packet->ptr;
    tcp_hdr = ip_hdr + SIZEOF_IPHDR;
    flag = tcp_hdr[tcphdr_flag];

    rec.ip = packet_get_nl(ip_hdr, iphdr_src_addr);
    rec.youport = packet_get_n(tcp_hdr, tcphdr_src_port);
    rec.myport = packet_get_n(tcp_hdr, tcphdr_dest_port);

    if (dest.status == LISTEN) {
	dest.ip = rec.ip;
	dest.youport = rec.youport;
	dest.myport = rec.myport;
    }
    
    if (dest.ip == rec.ip && dest.youport == rec.youport && dest.myport == rec.myport) {
	if (flag & TCP_FLAG_SYN) {
	    recepted = tcp_got_syn_packet(packet, &dest);
	} else if (flag & TCP_FLAG_PSH) {
	    recepted = tcp_got_normal_packet(packet, &dest);
	    http_output(packet);
	} else if (flag & TCP_FLAG_FIN) {
	    recepted = tcp_got_fin_packet(packet, &dest);
	} else if (flag & TCP_FLAG_ACK) {
	    tcp_got_ack_packet(packet, &dest);
	} else if (flag & TCP_FLAG_RST) {
	    dest.status = LISTEN;
	    sci_puts("tcp_input: LISTEN\n");
	}
    } else if (flag & TCP_FLAG_RST) {
	dest.status = LISTEN;
	sci_puts("tcp_input: LISTEN (debug!)\n");
	//send_tcp(RST?);		/* port ����ãmessage */
    } else {
	sci_puts("tcp_input: RST?\n");
    }
#endif /* HTTP */
#ifdef SMTP
    //static char smtp_status;
    
    ip_hdr = packet->ptr;
    tcp_hdr = ip_hdr + SIZEOF_IPHDR;
    flag = tcp_hdr[tcphdr_flag];

    rec.ip = packet_get_nl(ip_hdr, iphdr_src_addr);
    rec.youport = packet_get_n(tcp_hdr, tcphdr_src_port);
    rec.myport = packet_get_n(tcp_hdr, tcphdr_dest_port);

    if (dest.status == CLOSED) {
	dest.ip = rec.ip;
	dest.youport = rec.youport;
	dest.myport = rec.myport;
    }
    
    if (dest.ip == rec.ip && dest.youport == rec.youport && dest.myport == rec.myport) {
	if (flag & TCP_FLAG_SYN) {
	    recepted = tcp_got_syn_packet(packet, &dest);
            packet->flag = 0x00;
	} else if (flag & TCP_FLAG_PSH) {
            if (smtp_status != 8) {
                recepted = tcp_got_normal_packet(packet, &dest);
	        smtp_output(packet, 1);
            } else {
                smtp_status = 0;
            }
	} else if (flag & TCP_FLAG_FIN) {
	    recepted = tcp_got_fin_packet(packet, &dest);
	} else if (flag & TCP_FLAG_RST) {
	    sci_puts("tcp_input: (Receive RST) CLOSED\n");
	    dest.status = CLOSED;
	} else if (flag & TCP_FLAG_ACK) {
	    if (smtp_status == 6) {
		smtp_output(packet, 1);
	    } else {
		tcp_got_ack_packet(packet, &dest);
	    }
	}
    } else if (flag & TCP_FLAG_RST) {
	dest.status = CLOSED;
	sci_puts("tcp_input: CLOSED (debug!)\n");
	//send_tcp(RST?);		/* port ����ãmessage */
    } else {
	sci_puts("tcp_input: RST? (debug!)\n");
    }
#endif /* SMTP */
}

/* TCP�ǡ������Х롼���� */
/* sock : �̿�����ؤ�TCP�����åȹ�¤�� */
/* flags: ����ե饰                      */
/* packet:                                */
/* data : �����ǡ���                      */
/* size : �����ǡ����Υ�����              */
void send_tcp(T_TSOCK *sock, char flags, struct Packet *packet, char *data, unsigned int size)
{
    unsigned int tsize;
    unsigned int sum;
    char *ip_hdr;
    char *tcp_hdr;
    char *tcp_body;

    packet->ptr = packet->buffer + SIZEOF_ETHERHDR;
    packet->size = SIZEOF_TCPHDR + size;
    ip_hdr = packet->ptr;
    tcp_hdr = ip_hdr + SIZEOF_IPHDR;
    tcp_body = tcp_hdr + SIZEOF_TCPHDR;

#ifdef __SCI_DEBUG__
    sci_puts("send_tcp:\n");
#endif /*  __SCI_DEBUG__ */
    /* TCP payload */
    packet_memcpy(tcp_body, data, size);

    /* TCP header */
    packet_put_n(tcp_hdr, tcphdr_src_port, sock->myport);
    packet_put_n(tcp_hdr, tcphdr_dest_port, sock->youport);
    packet_put_nl(tcp_hdr, tcphdr_opt_mss, 0x020405b4); /* kind = 2, len = 4, mss = 1460 */
    tcp_hdr[tcphdr_len] &= 0x0f;
    tcp_hdr[tcphdr_len] |= (5 + 1) << 4; /* Unit is 32bit words */

    tcp_hdr[tcphdr_flag] = flags & 0x3f;
    //packet_put_n(tcp_hdr, tcphdr_win, 500);
    packet_put_n(tcp_hdr, tcphdr_chksum, 0);
    packet_put_n(tcp_hdr, tcphdr_urg, 0);

    packet_put_nl(tcp_hdr, tcphdr_ack, sock->ack);
    packet_put_nl(tcp_hdr, tcphdr_seq, sock->seq);

    /* pseudo header & checksum */
    packet_put_nl(tcp_hdr, pseudo_dest, node_ip_addr);
    packet_put_nl(tcp_hdr, pseudo_src, sock->ip);
    tcp_hdr[pseudo_zero]  = 0;
    tcp_hdr[pseudo_proto] = 6;
    tsize = size + SIZEOF_TCPHDR;
    if (size & 0x01) { 	/* size is odd */
	//tsize++;
  	tcp_hdr[tsize] = 0x00;
    }
    packet_put_n(tcp_hdr, pseudo_len, tsize);
    sum = calc_chksum(tcp_hdr + pseudo_src, tsize + 12);
    packet_put_n(tcp_hdr, tcphdr_chksum, sum);

    /* IP header */
    ip_hdr[iphdr_protocol] = IP_PROTO_TCP;
    packet_put_nl(ip_hdr, iphdr_src_addr, node_ip_addr);
    packet_put_nl(ip_hdr, iphdr_dest_addr, sock->ip);

    ip_output(packet);

    if (flags & (TCP_FLAG_SYN | TCP_FLAG_FIN)) {
	sock->seq++;
    } else if (size > 0) {
	sock->seq += size;
    }
}

