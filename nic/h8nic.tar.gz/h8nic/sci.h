/*****************************************************************
 *
 * $Id: sci.h,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $
 *
 * Reference:
 *	http://www.ertl.ics.tut.ac.jp/~muranaka/h8/
 *	sample-gcc.lzh
 *
 *****************************************************************/
#ifndef _SCI_H_
#define _SCI_H_

extern void sci_init();
extern unsigned char sci_putc(unsigned char ch);
extern unsigned char *sci_puts(unsigned char *buf);
extern unsigned char sci_getc(void);
extern unsigned char *sci_gets(char *buf);

#endif /* _SCI_H_ */
