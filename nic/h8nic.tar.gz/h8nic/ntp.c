/* $Id: ntp.c,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $ */
#include "tcpip.h"
#include "udp.h"
#include "ip.h"
#include "ether.h"
#include "lan-util.h"

void ntp_input(struct Packet *packet);
void ntp_clock();
void ntp_clockup();

static unsigned long TransmitTimestamp;

/* NTP ���� */
/* pkt: �ѥ��åȤؤΥݥ���  */
/* size: �ѥ��å�Ĺ           */
void ntp_input(struct Packet *packet)
{
    unsigned char *ntp_hdr;

    /* check mode bit (client or server? )*/
    sci_puts("ntp_input: got packet.\n TransmitTimestamp: ");
    packet->ptr = packet->buffer + SIZEOF_ETHERHDR + SIZEOF_IPHDR + SIZEOF_UDPHDR;
    ntp_hdr = packet->ptr;
    TransmitTimestamp = packet_get_nl(ntp_hdr, 40);

    sci_puts(hex22str(TransmitTimestamp >> 16));
    sci_puts(hex22str(TransmitTimestamp & 0xffff));
    sci_puts(": ");
    
    TransmitTimestamp -= (0x83AA7E80 - 9*3600); /* minus the seconds of 70 years + TZ(JST)*/
    sci_puts(hex22str((TransmitTimestamp) >> 16));
    sci_puts(hex22str((TransmitTimestamp) & 0xffff));
    sci_puts(": ");

    sci_puts(ctime(&TransmitTimestamp));
    ntp_clock();
}

/*  void ntp_output(struct Packet *packet) udp.c������� */
/*  { */
/*      ; */
/*  } */

void ntp_clock()
{
    char LcdBuffer1[] = "                ";	/* lcd buffer at line 1 */
    char LcdBuffer2[] = "                ";	/* lcd buffer at line 2 */
    char *ctimeBuffer;	/* ctime RAM buffer */
    unsigned char i;			/* counter */

    //sci_puts("ntp_clock: routine started.\n"); /* debug */
    
    ctimeBuffer = ctime(&TransmitTimestamp); /* minus the seconds of 70 years */
    /*  Thu Apr  4 17:14:19 2002 */
    for (i = 0; i < 10; ++i) {	/* "The Apr  4" */
	LcdBuffer1[i] = ctimeBuffer[i];
    }
    for (i = 0; i < 4; ++i) {	/* "2002" */
	LcdBuffer1[i + 11] = ctimeBuffer[i + 20];
    }
    for (i = 0; i < 8; ++i) {	/* "15:19:10" */
	LcdBuffer2[i + 2] = ctimeBuffer[i + 11];
    }
    LcdBuffer2[11] = 'J';
    LcdBuffer2[12] = 'S';
    LcdBuffer2[13] = 'T';

    /* Clear & Display */
    //LcdCls();
    LcdLocate(0,0);
    LcdPutStr(LcdBuffer1);
    
    LcdLocate(0,1);
    LcdPutStr(LcdBuffer2);
}

void ntp_clockup()
{
    ++TransmitTimestamp;
    ntp_clock();
}
