/****************************************************************
 * H8NIC Project
 * LCD driver header file
 *
 * $Id: lcd.h,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $
 *
 *****************************************************************/
#ifndef _LCD_H_
#define _LCD_H_

extern void LcdInit(void);
extern void LcdLocate(unsigned char x, unsigned char y);
extern void LcdCls(void);
extern void LcdDispCursor(unsigned char on);
extern void LcdBS(void);
extern void LcdPutCh(unsigned char c);
extern void LcdPutStr(unsigned char *str);

#endif /* _LCD_H_ */
