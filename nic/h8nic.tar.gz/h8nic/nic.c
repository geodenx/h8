/*****************************************************************
 * main routine
 * $Id: nic.c,v 1.2 2003/01/23 15:48:04 okazaki Exp $
 ****************************************************************/

#ifdef H8NIC
#include <3048f.h>
#elif AKI
#include <3067f.h>
#endif /* H8NIC|AKI */

#include <lcd.h>
#include <sci.h>
#include <eeprom.h>
#include <util.h>
#include "ne2000.h"
#include "ip.h"
#include "tcp.h"

#ifdef NTP
#include "ntp.h"
#endif /* NTP */

#define EnableIRQ asm("andc.b #0x7f,ccr")
#define DisableIRQ asm("orc.b #0x80,ccr")

extern void ne2000_input(void);
extern void ne2000_output(struct Packet *ptx);
/*  extern void ne2000_handler(void); */
extern char ne2000_probe(void);
extern char ne2000_init(void);

void bootstrap(void);
unsigned long get_addr(void);
void print_addr(unsigned long addr);
char SetRcpt(void);
unsigned char *addr2char(unsigned long addr);
unsigned long char2addr(char *buf);

/***************** NTP Interrupt Routine *****************/
#ifdef NTP
static unsigned char int_imia1_timer;
#pragma interrupt
void int_imia1(void)
{
#ifdef H8NIC
    ITU1.TSR.BIT.IMFA = 0;      /* clear interrupt request bit */
#elif AKI
    ITU.TISRA.BIT.IMFA1 = 0;      /* clear interrupt request bit */
#endif /* H8NIC|AKI */
    ++int_imia1_timer;
    if (int_imia1_timer > 39) {
	ntp_clockup();
	int_imia1_timer = 0;
    }
}
#endif /* NTP */

/***************** IRQ Interrupt Routine *****************/
#ifdef H8NIC
#pragma interrupt
void int_irq1(void)
{
    P4.DR.BIT.B0 = 1;
    sci_puts("int_irq1:\n");
}
#elif AKI
#pragma interrupt
void int_irq5(void)
{
    sci_puts("int_irq5:\n");
/*     INTC.ISR.BIT.IRQ5F = 0; */
}
#endif /* H8NIC|AKI */

/***************** Initial Routine *****************/
void InitITU()
{
    ITU0.TCR.BYTE = 0x23;       /* clear GRA comparematch,1/8clock */
    ITU1.TCR.BYTE = 0x23;       /* clear GRA comparematch,1/8clock      */
#ifdef H8NIC
    ITU0.GRA = 2000;		/* 1 msec = 62.5nsec * 8 * 2000 */
    ITU1.TIOR.BYTE = 0;         /* not use ITU pins                     */
    ITU1.TIER.BIT.IMIEA = 1;    /* Enable comparematch-A interrupt      */
    ITU1.GRA = 49999;           /* 25ms = 62.5ns * 8 * 50000            */
#elif AKI
    ITU0.GRA = 2500;		/* 1 msec = 50.0nsec * 8 * 2500 */
    ITU1.TIOR.BYTE = 0;         /* not use ITU pins                     */
    ITU.TISRA.BIT.IMIEA1 = 1;   /* Enable comparematch-A interrupt      */
    ITU1.GRA = 49999;           /* 25ms = 62.5ns * 8 * 50000            */
#endif
    ITU.TSTR.BYTE = 0xe3;       /* Start ITU ch0 ch1                    */
}

void InitPort(void)
{
#ifdef H8NIC
    P8.DDR = 0xEC;		/* !Enable ^CS1, ^CS2 */
    P4.DDR = 0x03;		/* 0000-0011 P40,1=LED, P42,3=SW */
    P4.PCR.BYTE = 0x0C;		/* 0000-1100 */
#elif AKI
    P8DDR = 0xEC;		/* !Enable ^CS1, ^CS2 */
    P4DDR = 0xD3;		/* 1101-0011 P40,1=LED, P42,3=SW, P47=LCD::E */
    P4PCR.BYTE = 0x2C;		/* 0010-1100 */
    P6DDR = 0x00;		/* for EEPROM */
/* when non monitor */
    P1DDR = 0xFF;
    P2DDR = 0x07;
#endif
/* Hitachi monitor (Monitor.src)�Ǥ�äƤ���Port�ν��������ʤ��� */
/* ������񤯤ȸ�ư��� ROM������Ȥ����� */
/*    BSC.ASTCR.BYTE = 0xFB; */
/*    BSC.WCER.BYTE = 0xFF; */
/*    BSC.WCR.BYTE = 0x03; */
}

/***************** Main Routine *****************/
int main(void)
{    
    InitPort();
    InitITU();
    sci_init();
    waitms(400);

#ifdef NTP
    EnableIRQ;
    LcdInit();
    LcdCls();
    LcdPutStr("H8NIC NTP");
#endif /* NTP */

#ifdef AKI
#ifdef SMTP
/*     INTC.IER.BIT.IRQ5E = 1; */
/*     INTC.ISCR.BIT.IRQ5SC = 0; (init value) */
/*     EnableIRQ; */
/*     P4DR.BIT.B0 = 1; */
/*     P4DR.BIT.B1 = 1; */
    bootstrap();
#endif /* SMTP */
#endif /* AKI*/

    while (1) {
	ne2000_probe();	 /* read_saprom(); PROM����MAC address���ɤ�*/
 	ne2000_init();
	ne2000_input();
	waitms(1000);
	sci_puts("Error: main: ne2000_input exit.\n");
    }
}

/******************************************************************/
#ifdef AKI
#ifdef SMTP
void bootstrap(void)
{
    char buf[4];

    sci_puts("bootstrap:\n");
    if (!P4DR.BIT.B5) {
	while (1) {
	    sci_puts("IPv4 configuration\n\tIP: ");
	    if ((node_ip_addr = get_addr()) == 0) {
		continue;
	    }
	    print_addr(node_ip_addr);

	    sci_puts("\tsubnet mask: ");
	    if ((subnet_mask = get_addr()) == 0) {
		continue;
	    }
	    print_addr(subnet_mask);

	    sci_puts("\tGateway: ");
	    if ((default_gateway = get_addr()) == 0) {
		continue;
	    }
	    print_addr(default_gateway);

	    sci_puts("SMTP configuration\n\tSMTP Server: ");
	    if ((smtp_server = get_addr()) == 0) {
		continue;
	    }
	    print_addr(smtp_server);

	    sci_puts("\tRCPT TO: ");
	    if (SetRcpt() == 0) {
		continue;
	    }
	    break;
	}
	/* save eeprom */
	if (eeprom_write(0, addr2char(node_ip_addr),4) != 0) {
	    sci_puts("Error: bootstrap: cannot write node_ip_addr in eeprom.\n");
	}
	waitms(100);
	if (eeprom_write(4, addr2char(subnet_mask), 4) != 0) {
	    sci_puts("Error: bootstrap: cannot write subnet_mask in eeprom.\n");
	}
	waitms(100);
	if (eeprom_write(8, addr2char(default_gateway), 4) != 0) {
	    sci_puts("Error: bootstrap: cannot write default_gateway in eeprom.\n");
	}
	waitms(100);
	if (eeprom_write(12, addr2char(smtp_server), 4) != 0) {
	    sci_puts("Error: bootstrap: cannot write smtp_server in eeprom.\n");
	}
	waitms(100);
  	if (eeprom_write(16, rcpt, 100) != 0) {
	    sci_puts("Error: bootstrap: cannot write rcpt in eeprom.\n");
	}
    } else {
	/* load configration from eeprom*/
	if (eeprom_read(0, buf, 4) != 0) {
	    sci_puts("Error: bootstrap: cannot read node_ip_addr in eeprom.\n");
	}
	node_ip_addr = char2addr(buf);
	waitms(100);

	if (eeprom_read(4, buf, 4) != 0) {
	    sci_puts("Error: bootstrap: cannot read subnet_mask in eeprom.\n");
	}
	subnet_mask = char2addr(buf);
	waitms(100);
	    
        if (eeprom_read(8, buf, 4) != 0 ) {
	    sci_puts("Error: bootstrap: cannot read default_gateway in eeprom.\n");
	}
	default_gateway = char2addr(buf);
	waitms(100);

        if (eeprom_read(12, buf, 4) != 0) {
	    sci_puts("Error: bootstrap: cannot read smtp_server in eeprom.\n");
	}
	smtp_server = char2addr(buf);
	waitms(100);

	if (eeprom_read(16, rcpt, 100) != 0) {
	    sci_puts("Error: bootstrap: cannot read rcpt in eeprom.\n");
	}

	sci_puts("\tnode_ip_addr: ");
	print_addr(node_ip_addr);
	sci_puts("\tsubnet_mask: ");
	print_addr(subnet_mask);
	sci_puts("\tdefault_gateway: ");
	print_addr(default_gateway);
	sci_puts("\tsmtp_server: ");
	print_addr(smtp_server);
	sci_puts("\trcpt: ");
	sci_puts(rcpt);
    }
}

unsigned long get_addr(void)
{
    unsigned long addr = 0x00000000;
    unsigned char c, i, j, d[3], buf = 0;

    for (j = 0, i = 0; i < 4;) {
	c = sci_getc();
	if (c == '.' || c == '\n') {
	    if (i == 0) {
		sci_puts("Error: get_addr (1): unexpected char\n");
		return 0;
	    } else if (i == 1) {
		buf = d[0];
	    } else if (i == 2) {
		buf = d[0]*10 + d[1];
	    } else if (i == 3) {
		buf = d[0]*100 + d[1]*10 + d[2];
	    }
/* 	    if (buf > 255) { unsigned char(2byte)������256��0�ˤʤ�ΤǸ��ФǤ��ʤ� */
/* 		sci_puts("Error: get_addr (2): unexpected address (0 =< address =< 255)\n"); */
/* 		return 0; */
/* 	    } */
	    addr |= buf;
	    if (c == '\n') {
		break;
	    }
	    addr <<= 8;
	    ++j;
	    i = 0;
	} else if (c >= '0' && c <= '9') {
	    if (i == 3) {
		sci_puts("Error: get_addr (3): unexpected char\n");
		return 0;
	    }
	    if (i == 0) {
		d[0] = c - 0x30;
	    } else if (i == 1) {
		d[1] = c - 0x30;
	    } else if (i == 2) {
		d[2] = c - 0x30;
	    }
	    ++i;
	} else {
	    sci_puts("Error: get_addr (4): unexpected char\n");
	    return 0;
	}
    }

    if (j != 3) {
	sci_puts("Error: get_addr (5): less or many segment for IPv4.\n");
	return 0;
    }

    return addr;
}

void print_addr(unsigned long addr)
{
    unsigned long buf;

    buf = addr;
    sci_puts(hex2str(buf >> 24));
    sci_putc('.');

    buf = addr;
    sci_puts(hex2str((buf & 0x00ff0000) >> 16));
    sci_putc('.');

    buf = addr;
    sci_puts(hex2str((buf & 0x0000ff00) >> 8));
    sci_putc('.');

    buf = addr;
    sci_puts(hex2str(buf & 0x000000ff));
    sci_putc('\n');
}

char SetRcpt(void)
{
    unsigned char c, i;
    
    for (i = 9; (c = sci_getc()) != '\n'; ++i) {
	rcpt[i] = c;
    }
    rcpt[i] = '\r'; ++i;
    rcpt[i] = '\n'; ++i;
    rcpt[i] = '\0'; ++i;
    sci_puts(rcpt);

    return (i - 9);
}

unsigned char addr2char_buf[4];
unsigned char *addr2char(unsigned long addr)
{

    addr2char_buf[3] = (unsigned char)(addr & 0x000000ff);
    addr2char_buf[2] = (unsigned char)((addr >> 8) & 0x000000ff);
    addr2char_buf[1] = (unsigned char)((addr >> 16) & 0x000000ff);
    addr2char_buf[0] = (unsigned char)((addr >> 24) & 0x000000ff);

/*     sci_puts(hex2str(addr2char_buf[0])); */
/*     sci_puts(hex2str(addr2char_buf[1])); */
/*     sci_puts(hex2str(addr2char_buf[2])); */
/*     sci_puts(hex2str(addr2char_buf[3])); */

    return addr2char_buf;
}

unsigned long char2addr(char *buf)
{
    unsigned long addr;

    addr  = (unsigned long)buf[0]; addr <<= 8;
    addr |= (unsigned long)buf[1]; addr <<= 8;
    addr |= (unsigned long)buf[2]; addr <<= 8;
    addr |= (unsigned long)buf[3];

    return addr;
}
#endif /* SMTP */
#endif /* AKI */
