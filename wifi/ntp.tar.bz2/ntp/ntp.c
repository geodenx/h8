/*
  $Id$
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
//#include <sys/param.h>
#include <sys/uio.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>

#include "3069s.h"
#include "lcd.c"

/* #define EnableIRQ asm("andc.b #0x7f,ccr") */
/* #define DisableIRQ asm("orc.b #0x80,ccr") */
/* #define inb(x) *(unsigned char *)(x) */
/* #define outb(x, y) *(unsigned char *)(x) = (y) */

#define	NTP_PORT	123
#define	BUFLEN		256

typedef signed char s8;
typedef unsigned char u8;
typedef signed short s16;
typedef unsigned short u16;
typedef signed int s32;
typedef unsigned int u32;

typedef struct {
    u32 l_ui;
    u32 l_uf;
} l_fp;

struct ntp_pkt {
    u8	li_vn_mode;	/* leap indicator, version and mode */
    u8	stratum;	/* peer stratum */
    u8	ppoll;		/* peer poll interval */
    u8	precision;	/* peer clock precision */
    u32	rootdelay;	/* distance to primary clock */
    u32	rootdispersion;	/* clock dispersion */
    u32	refid;		/* reference clock ID */
    l_fp reftime;	/* time peer clock was last updated */
    l_fp org;		/* originate time stamp */
    l_fp rec;		/* receive time stamp */
    l_fp xmt;		/* transmit time stamp */
};

void ntp_clock(char *host);
void ntp_display(u32 xmt);
void InitPort(void);

int main(int argc, char *argv[])
{
    InitPort();
    LcdPutStr("wlan-h8");
    LcdLocate(0,1);
    LcdPutStr("NTP Clock");

    if ( argc == 2 ){
	ntp_clock(argv[1]);
    } else {
/*         fprintf(stderr, "usage:\n\t%s server\n", argv[0]); */
        exit(1);
    }

    return 0;
}

void ntp_clock(char *host)
{
    struct ntp_pkt pkt;
    int f;
    struct hostent *servhost;
    struct sockaddr_in server;
    struct sockaddr_storage from;
    int fromlen;

    servhost = gethostbyname(host);
    if ( servhost == NULL ){
/*         fprintf(stderr, "bad hostname [%s]\n", host); */
        exit(1);
    }

    bzero((char*)&server, sizeof(server));
    server.sin_family = AF_INET;
    bcopy(servhost->h_addr, (char *)&server.sin_addr, servhost->h_length);
    server.sin_port = htons(NTP_PORT);

    if ((f = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
/* 	perror("ntp: socket"); */
	exit(1);
    }
    
    bzero(&pkt, sizeof(struct ntp_pkt));
    pkt.li_vn_mode = 0x0b;
    if (sendto(f, &pkt, sizeof(struct ntp_pkt), 0, (struct sockaddr *)&server, sizeof(server)) < 0) {
/* 	perror("ntp: sendto"); */
	exit(1);
    }

    fromlen = sizeof(from);
    if (recvfrom(f, &pkt, sizeof(struct ntp_pkt), 0, (struct sockaddr *)&from, &fromlen) < 0) {
/* 	perror("ntp: recvfrom"); */
	exit(1);
    }

/*     printf("%02x ", pkt.li_vn_mode); */
/*     printf("%02x ", pkt.stratum); */
/*     printf("%02x ", pkt.ppoll); */
/*     printf("%02x\n", pkt.precision); */
/*     printf("%08x\n", ntohl(pkt.rootdelay)); */
/*     printf("%08x\n", ntohl(pkt.rootdispersion)); */
/*     printf("%08x\n", ntohl(pkt.refid)); */
/*     printf("%08x %08x\n", ntohl(pkt.reftime.l_ui), ntohl(pkt.reftime.l_uf)); */
/*     printf("%08x %08x\n", ntohl(pkt.org.l_ui), ntohl(pkt.org.l_uf)); */
/*     printf("%08x %08x\n", ntohl(pkt.rec.l_ui), ntohl(pkt.rec.l_uf)); */
/*     printf("%08x %08x\n", ntohl(pkt.xmt.l_ui), ntohl(pkt.xmt.l_uf)); */

    ntp_display(ntohl(pkt.xmt.l_ui));
}

void ntp_display(u32 xmt)
{
    char LcdBuffer1[] = "                ";     /* lcd buffer at line 1 */
    char LcdBuffer2[] = "                ";     /* lcd buffer at line 2 */
    char *ctimeBuffer;  /* ctime RAM buffer */
    unsigned char i;                    /* counter */

    xmt -= (0x83AA7E80 - 9*3600); /* minus the seconds of 70 years + TZ(JST)*/
    while (1) {
	ctimeBuffer = ctime((time_t *)&xmt);

	/*  Thu Apr  4 17:14:19 2002 */
	for (i = 0; i < 10; ++i) {  /* "The Apr  4" */
	    LcdBuffer1[i] = ctimeBuffer[i];
	}
	for (i = 0; i < 4; ++i) {   /* "2002" */
	    LcdBuffer1[i + 11] = ctimeBuffer[i + 20];
	}
	for (i = 0; i < 8; ++i) {   /* "15:19:10" */
	    LcdBuffer2[i + 2] = ctimeBuffer[i + 11];
	}
	LcdBuffer2[11] = 'J';
	LcdBuffer2[12] = 'S';
	LcdBuffer2[13] = 'T';
/*     printf("    : 0123456789abcdef\n"); */
/*     printf("LCD1: %s\n", LcdBuffer1); */
/*     printf("LCD2: %s\n", LcdBuffer2); */
	LcdLocate(0,0);
	LcdPutStr(LcdBuffer1);
	LcdLocate(0,1);
	LcdPutStr(LcdBuffer2);

	sleep(1);
	xmt++;
    }
}

void InitPort(void)
{
    P1DDR = 0xFF;		/* Port1 address output (A0-7) */
    P2DDR = 0x07;		/* Port2 address output (A8-10) */
    P4DDR = 0xFF;		/* Port4 data direction register output (P40-P47) */
    P8DDR = 0xEE;		/* b'11101110 Enable ^CS1, ^CS2 ^CS3 */
    BSC.CSCR.BYTE = 0x1f;	/* enable ^CS4 */
    LcdInit();
}
