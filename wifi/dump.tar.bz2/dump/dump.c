/*
  CIS dump
  $Id$

  usage:
  case RedBoot
  RedBoot> load -v -m TFTP -b 0x400000 dump.mot; go 0x400000
*/

#include "3069s.h"
#include "sci.h"

#define EnableIRQ asm("andc.b #0x7f,ccr")
#define DisableIRQ asm("orc.b #0x80,ccr")
#define inb(x) *(unsigned char *)(x)
#define outb(x, y) *(unsigned char *)(x) = (y)

unsigned char *hex2str(unsigned char c);
void InitPort(void);
void SoftReset(void);

int main(void)
{
    unsigned long int address;
    unsigned short i;

    sci_init();
    InitPort();

    for (i = 0; i < 2; i++) {
	sci_puts("\n0x200000 (RTL8019AS)\n");
	for (address = 0x200000; address < 0x200040; address++)
	    sci_puts(hex2str(inb(address)));
	sci_puts("\n0x400000 (DRAM)\n");
	for (address = 0x400000; address < 0x400040; address++)
	    sci_puts(hex2str(inb(address)));
	sci_puts("\n0x600000 (CF attribute even byte only)");
	for (address = 0x600000; address < 0x600400; address++) {
	    if (!(address % 0x40)) sci_puts("\n");
	    if ((address % 0x10) == 0) sci_puts(" ");
	    if (!(address % 0x02)) sci_puts(hex2str(inb(address)));
	}
 	sci_puts("\n0x800000 (CF I/O)");
	for (address = 0x800000; address < 0x800100; address++) {
	    if (!(address % 0x40)) sci_puts("\n");
	    if ((address % 0x10) == 0) sci_puts(" ");
	    sci_puts(hex2str(inb(address++)));
	    sci_puts(hex2str(inb(address)));
	}
#define SOFT_RESET
#ifdef SOFT_RESET
	if (i == 0) {
	    sci_puts("\n");
	    SoftReset();
	}
#endif /* SOFT_RESET */
    }
    while (1);

    return 0;
}

void InitPort(void)
{
    P1DDR = 0xFF;		/* Port1 address output (A0-7) */
    P2DDR = 0x07;		/* Port2 address output (A8-10) */
/*     P4DDR = 0xFF;		/\* Port4 data direction register output (P40-P47) *\/ */
    P8DDR = 0xEE;		/* b'11101110 Enable ^CS1, ^CS2 ^CS3 */
/*     P8DDR = 0xEA;		/\* b'11101010 Enable ^CS1, ^CS3 *\/ */
    BSC.CSCR.BYTE = 0x1f;	/* enable ^CS4 */

/*     BSC.RTCOR = 155;		/\* Refresh about 64kHz *\/ */
    BSC.RTCOR = 99;		/* Refresh about 100kHz */
    BSC.RTMCSR.BYTE = 0x0f;	/* b'0000 1111 $B&5(B2 */
    BSC.DRCRB.BYTE = 0x98;	/* b'1001 1000 column address 10 bit */
    BSC.DRCRA.BYTE = 0x3c;	/* Area2 DRAM Space, FP mode, RAS down mode */

/*     BSC.ASTCR.BYTE = 0xe3;     /\* b'1110 0011 Area2-4 2 state access *\/ */
/*     BSC.ASTCR.BYTE = 0xfb;     /\* b'1111 1011 Area2 2 state access, Area3-4 3 state *\/ */
    BSC.ASTCR.BIT.AST2 = 0;	/* H8::^CS2 - DRAM::^RAS 2 state */
    BSC.ASTCR.BIT.AST3 = 1;	/* Area3 (CF: Attribute Space) state */
    BSC.ASTCR.BIT.AST4 = 1;	/* Area4 (CF: I/O Space) state */
    BSC.WCR.BIT.W3 = 3;		/* Area3 wait */
    BSC.WCR.BIT.W4 = 3;		/* Area4 wait */
    BSC.BCR.BIT.WAITE = 1;	/* Enable ^WAIT pin */

    sci_puts("InitPort: BSC.CSCR.BYTE: ");
    sci_puts(hex2str(BSC.CSCR.BYTE));
    sci_puts("\nInitPort: BSC.ASTCR.BYTE: ");
    sci_puts(hex2str(BSC.ASTCR.BYTE));
    sci_puts("\nInitPort: BSC.WCR.BYTE.H: ");
    sci_puts(hex2str(BSC.WCR.BYTE.H));
    sci_puts("\nInitPort: BSC.WCR.BYTE.L: ");
    sci_puts(hex2str(BSC.WCR.BYTE.L));
    sci_puts("\nInitPort: BSC.BCR.BYTE: ");
    sci_puts(hex2str(BSC.BCR.BYTE));
    sci_puts("\nInitPort: BSC.DRCRA.BYTE: ");
    sci_puts(hex2str(BSC.DRCRA.BYTE));
    sci_puts("\nInitPort: BSC.DRCRB.BYTE: ");
    sci_puts(hex2str(BSC.DRCRB.BYTE));
    sci_puts("\n");
}

void SoftReset(void)
{
    unsigned long int i;

    sci_puts("Software Reset\n");
    outb(0x6003e0, 0x81);
    for (i = 0; i < 0x08000; i++);
    outb(0x6003e0, 0x01);
    for (i = 0; i < 0x08000; i++);
}

static unsigned char hex2str_s[3];	/* global variable for hex2str */
unsigned char *hex2str(unsigned char c)
{
    static char hex[17] = "0123456789ABCDEF";

    hex2str_s[0] = hex[ c >> 4 ];
    hex2str_s[1] = hex[ c & 0x0f ];
    hex2str_s[2] = '\0';
    
    return hex2str_s;
}
