;****************************************************************
;
; $Id: crt0.s,v 1.1.1.1 2003/01/23 14:46:19 okazaki Exp $ 
; 
;****************************************************************

; h8comm-0.1/h8crt0.S
; h8/300 and h8/300h start up file.

	.h8300h
	.section .text
	.global	_start
_start:
	mov.l	#_stack,sp
	;; copy DATA from ROM
	mov.l	#___dtors_end,er0
	mov.l	#_edata,er1
	mov.l	#___data,er2
.loop0:	mov.w	@er0,r3
	mov.w	r3,@er2
	adds	#2,er0
	adds	#2,er2
	cmp.l	er1,er2
	blo	.loop0
	
	;; clear BSS
	mov.l	#_edata,er0
	mov.l	#_end,er1
	mov.w	#0,r2
.loop:	mov.w	r2,@er0
	adds	#2,er0
	cmp.l	er1,er0
	blo	.loop
	jsr	@_main
	bra	_start

	.section .stack
_stack:	.long 	1

