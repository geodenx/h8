#include <stdio.h>
#include "3069s.h"

#define inb(x) *(unsigned char *)(x)
#define outb(x, y) *(unsigned char *)(x) = (y)

void InitPort(void);
void SoftReset(void);

int main(int argc, char *argv[])
{
    unsigned long int address;
    unsigned short i;

    InitPort();

    for (i = 0; i < 2; i++) {
	printf("\n0x200000 (RTL8019AS)\n");
	for (address = 0x200000; address < 0x200040; address++)
	    printf("%02x", inb(address));
	printf("\n0x400000 (DRAM)\n");
	for (address = 0x400000; address < 0x400040; address++)
	    printf("%02x", inb(address));
	printf("\n0x600000 (CF attribute even byte only)");
	for (address = 0x600000; address < 0x600400; address++) {
	    if (!(address % 0x40)) printf("\n");
	    if ((address % 0x10) == 0) printf(" ");
	    if (!(address % 0x02)) printf("%02x", inb(address));
	}
 	printf("\n0x800000 (CF I/O)");
	for (address = 0x800000; address < 0x800100; address++) {
	    if (!(address % 0x40)) printf("\n");
	    if ((address % 0x10) == 0) printf(" ");
	    printf("%02x", inb(address++));
	    printf("%02x", inb(address));
	}
	printf("\n");
#define SOFT_RESET
#ifdef SOFT_RESET
	if (i == 0) {
	    SoftReset();
	}
#endif /* SOFT_RESET */
    }

    return 0;
}

void InitPort(void)
{

/*     P1DDR = 0xFF;		/\* Port1 address output (A0-7) *\/ */
/*     P2DDR = 0x07;		/\* Port2 address output (A8-10) *\/ */

/*     P8DDR = 0xEE;		/\* b'11101110 Enable ^CS1, ^CS2 ^CS3 *\/ */
/*     BSC.CSCR.BYTE = 0x1f;	/\* enable ^CS4 *\/ */

/*     BSC.ASTCR.BIT.AST3 = 1;	/\* Area3 (CF: Attribute Space) state *\/ */
/*     BSC.ASTCR.BIT.AST4 = 1;	/\* Area4 (CF: I/O Space) state *\/ */
/*     BSC.WCR.BIT.W3 = 3;		/\* Area3 wait *\/ */
/*     BSC.WCR.BIT.W4 = 3;		/\* Area4 wait *\/ */
/*     BSC.BCR.BIT.WAITE = 1;	/\* Enable ^WAIT pin *\/ */
/*     BSC.DRCRA.BIT.DRAS = 0x1;	/\* (DRAS2, DRAS1, DRAS0) = 3b'001  DRAM space area 2 only*\/ */

    printf("InitPort: BSC.CSCR.BYTE: %02x\n",  BSC.CSCR.BYTE);
    printf("InitPort: BSC.ASTCR.BYTE: %02x\n", BSC.ASTCR.BYTE);
    printf("InitPort: BSC.WCR.BYTE.H: %02x\n", BSC.WCR.BYTE.H);
    printf("InitPort: BSC.WCR.BYTE.L: %02x\n", BSC.WCR.BYTE.L);
    printf("InitPort: BSC.BCR.BYTE: %02x\n",   BSC.BCR.BYTE);
    printf("InitPort: BSC.DRCRA.BYTE: %02x\n", BSC.DRCRA.BYTE);
    printf("InitPort: BSC.DRCRB.BYTE: %02x\n", BSC.DRCRB.BYTE);
}

void SoftReset(void)
{
    unsigned long int i;

    printf("Software Reset\n");
    outb(0x6003e0, 0x81);
    for (i = 0; i < 0x08000; i++);
    outb(0x6003e0, 0x01);
    for (i = 0; i < 0x08000; i++);
}
