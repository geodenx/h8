#include <stdio.h>
#include <unistd.h>

void main()
{
	while (1) {
		printf("Hello, world from uclinux-h8!\n");
		sleep(1);
	}
}
