/* $Id$ */
#include <stdio.h>
#include "3069s.h"
#include "sci.h"

void InitPort(void);
unsigned char buf[256];

int main(void)
{

    sci_init();
    InitPort();
    sprintf(buf, "Hello World!\n");
    sci_puts(buf);

    return 0;
}

void InitPort(void)
{
    P1DDR = 0xFF;		/* Port1 address output (A0-7) */
    P2DDR = 0x07;		/* Port2 address output (A8-10) */
/*     P4DDR = 0xFF;		/\* Port4 data direction register output (P40-P47) *\/ */
    P8DDR = 0xEE;		/* b'11101110 Enable ^CS1, ^CS2 ^CS3 */
/*     P8DDR = 0xEA;		/\* b'11101010 Enable ^CS1, ^CS3 *\/ */
    BSC.CSCR.BYTE = 0x1f;	/* enable ^CS4 */

/*     BSC.RTCOR = 155;		/\* Refresh about 64kHz *\/ */
    BSC.RTCOR = 99;		/* Refresh about 100kHz */
    BSC.RTMCSR.BYTE = 0x0f;	/* b'0000 1111 $B&5(B2 */
    BSC.DRCRB.BYTE = 0x98;	/* b'1001 1000 column address 10 bit */
    BSC.DRCRA.BYTE = 0x3c;	/* Area2 DRAM Space, FP mode, RAS down mode */

/*     BSC.ASTCR.BYTE = 0xe3;     /\* b'1110 0011 Area2-4 2 state access *\/ */
/*     BSC.ASTCR.BYTE = 0xfb;     /\* b'1111 1011 Area2 2 state access, Area3-4 3 state *\/ */
    BSC.ASTCR.BIT.AST2 = 0;	/* H8::^CS2 - DRAM::^RAS 2 state */
    BSC.ASTCR.BIT.AST3 = 1;	/* Area3 (CF: Attribute Space) state */
    BSC.ASTCR.BIT.AST4 = 1;	/* Area4 (CF: I/O Space) state */
    BSC.WCR.BIT.W3 = 1;		/* Area3 wait */
    BSC.WCR.BIT.W4 = 1;		/* Area4 wait */
    BSC.BCR.BIT.WAITE = 1;	/* Enable ^WAIT pin */
}
